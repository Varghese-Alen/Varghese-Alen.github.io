# M3 Capsule — complete digital prototype design

**UNPROTOTYPED: qualify fabrication coupons, real interfaces and selected hardware before a complete case cut.** Digital completion is not a tested product, handle rating, guaranteed component fit, USB certification or safety approval.

Licensed **CERN-OHL-P-2.0**. Full license: `LICENSE.txt`; third-party notice: `NOTICE.md`.

## Start here

- **`M3-Capsule-drawings-and-build-guide.pdf` — 41 A3 pages:** dimensions, individual developed blanks, bends, BOM, assembly/service, completed I/O mounting/wiring and physical qualification plan.
- **`CAD/M3-Capsule.FCStd`:** authoritative editable assembly. Manufactured sheets, reference hardware and nonmaterial I/O routing constructions are distinguished in the tree.
- **`CAD/M3-Capsule-flats.FCStd`:** editable individual blanks, not a cutting nest. Hide all except the selected PartID when inspecting overlapping local-coordinate blanks.
- **`CAD/M3-Capsule-assembly.step`:** coloured solid assembly, including nominal hardware/component envelopes; nonmaterial routing wires are excluded.
- **`CAD/M3-Capsule-panels.step`:** 19 manufactured sheet instances only, uncoloured. Do not manufacture the reference component boxes.
- **`DXF/`:** millimetres, cut-only curves; bend lines are in the PDF/CSV, not laser-cut entities.
- **`IO-ASSEMBLY.md` and `io-interfaces.json`:** exact selected I/O topology, mounting stack, assumptions, variants, source links and installation checks.

## Front I/O is now integrated

The default fascia has **two C, two A, stereo audio and power**, with a shared concealed I03 mounting plate, real fixings and protected routing allocations. No unfinished USB crossbars or sample-only port templates remain in this release.

| Function | Selected parts / connection |
|---|---|
| Two C sockets | Two Newnex U4S5C01C08-010 panel cables; each male end connects through its own Delock67234 to an independent Type-E/Key-A motherboard or controller port |
| Two A sockets | Two Newnex USR2-AA-1M panel cables connected to Delock82941, using one conventional two-port 19-pin USB3 motherboard header |
| Stereo audio | FRONTX P0902_036, 36in lead through the protected rear exit to a suitable rear stereo output; **not HD_AUDIO, headset microphone or an amplifier** |
| Power | Existing E-Switch PV0F24011 and insulated PWR_SW pair |

These substitute for the previously proposed Delock85760/85244 and Adafruit3319 interfaces because the selected panel modules have better public mechanical evidence. The design uses **commercial passive extension/header adapters**, not direct internal harnesses. Added connections require actual whole-chain enumeration, speed, current and all four local C-orientation combinations (2 rear ×2 front); repeat for a reversible device-end plug. No USB-IF, PD, Alt Mode, USB4 or Thunderbolt claim. Use standard5V host operation only; no passive Y splitter, legacy-A-to-C receptacle adapter or A-male/A-male cable.

One supported Type-E header means **use the one-C fascia**, omit the lower C module and its adapter/fixings. Do not install a dead-looking second port. Alternative quantities are listed in `IO-ASSEMBLY.md`.

### What is sourced and what is allocated

Published flange dimensions, mounting pitches, C nose projection and rear-body/relief limits control the mounting design. Simplified component bodies are **not exact OEM CAD**. Unpublished corners, embedded-nut depth, A nose projection, cable bend limits and retail variant tolerances remain receiving/fit checks, not invented manufacturer dimensions.

C14×8R2 and A20×12R1 are designer access openings, slightly larger than the earlier artwork. Port centres and the42×164 capsule are unchanged. C recess1.3mm is derived from its published3.2mm nose; A4.5mm is a reserve recess, not an OEM-exact setback. Use actual C plug hoods ≤12.2×6.4 and A≤18×10 as nominal access limits; qualify finish/corners and insertion. USB screw-head/fascia gap0.35mm and attachment-head/wrap gap0.85mm need finished-stack checks. Audio finished panel thickness must be **strictly below1.2mm**.

R50/Ø10 USB routing constructions are designer clearance allocations, not supplier minimum-bend or cable-OD specifications. Header tails depend on the selected motherboard. Secure all added mating pairs, support leads near headers and keep cables away from fans. The audio hood must pass the bareØ12 rear hole before fitting the split grommet: maximum allowed hoodØ11; do not force a plug through the nominalØ9 grommet bore.

## Approved case geometry retained

- Main shell: **302 W ×410 D ×520 H mm**; upper width **290mm**.
- Including ordinary pan heads and rear rail: **306.8 W ×422 D ×520 H mm**. The earlier2.2mm overall-width increase was entirely the change from illustrative1.3mm to ordinary2.4mm screw heads; side planes did not move.
- Sand sleds, forward handles, lower joggle, concentric capsule ventilation and charcoal single wrap remain.
- No welding. Two ordinary M3×10 front bolts retain the carrier. The new I03 mounts to that carrier, with no additional shell holes or visible fascia screws.
- Handles are **UNRATED: empty-case handling only until physically load-qualified**.

## Manufacturing files and quantities

**18 main sheet designs /19 instances**, including opposite-handed sleds from one blank. F01 side-fan bridge and G01/G02 GPU support are optional. I03 is included in the full and one-C versions, omitted from power-only/blank versions.

**29 DXFs total:**18 main,3 mutually exclusive fascia alternatives,6 process coupons,2 ancillary designs (ten0.2mm shims and one0.5mm gasket). Alternatives are substitutions, not extra installed sheets. Obsolete sample-gated port templates have been removed.

- `panels.json`, `sheet-parts-bom.csv`: IDs, materials, gauges, quantities, blank sizes and unfinished material mass estimates.
- `bend-schedule.csv`: exact flat-coordinate axes, signed path-turn angles, R/K/BA and forming order. Consult assembled PDF sections for UP/DOWN direction.
- `flat-hole-schedule.csv`, `drawing-geometry.json`: complete hole/analytic geometry data.
- `hardware-bom.csv`, `purchased-components.csv`, `joint-schedule.csv`: purchasing, nominal stacks and access. Purchasing entries already present in the hardware BOM are not additional quantities.
- `ASSEMBLY-NOTES.md`: chassis assembly and critical motherboard/PCI datums.
- `references.json` and `io-interfaces.json`: public sources and their limitations; supplier drawings are cited, not redistributed or relicensed.

K factors, radii and springback are provisional shop assumptions. Qualify material/joggle/insert coupons and segmented-brake access before cutting the1238.0503mm wrap. Use appropriate metalworking equipment and small-feature capability; deburr every handle, vent and cable passage. Do not scale PDF pictures or add kerf compensation to the master geometry.

## Digital checks

- **287 solid-bearing leaves /290 solids**, valid native and coloured STEP, equal summed volume **10,045,657.470mm³**, identical bounds. Reference envelopes are included in this volume; it is not enclosure material volume or mass.
- All **19 main sheet instances** valid single solids; no sheet/sheet interference.
- **29 serialized DXFs /2,408 closed loops**, no open/duplicate cuts; maximum area mismatch **1.518×10⁻⁶mm²**.
- **2,333 circular cuts** mapped through development to assembled holes and saved DXFs; maximum coordinate error **4.951×10⁻⁹mm**.
- Portable source rebuild and repeated I/O update reproduced counts, volume and bounds.
- New I/O plate/hardware: zero unexpected solid clashes. Ten continuous swept routing allocations checked; minimum nominal USB route clearance3mm, audio approximately2.994mm. This does not qualify unplaced board-specific tails or supplier bend limits.
- Nine existing PCI major-thread/tap-drill overlaps and eight SSD/PSU screw/reference-envelope penetrations remain explicitly identified; actual allowed penetration is not waived. No STL validation claimed.

See `export-validation.json`, `io-export-validation.json`, `model-export-check.json`, `io-clearance-check.json`, `development-check.json`, `folded-hole-alignment.json`, `dxf-validation.json`, `assembly-check.json`, `reference-intersections.json` and `io-source-validation.json`.

## Physical qualification still required

Process coupons/tool access; actual PCI/card/cover and rear-I/O gauge; selected motherboard/RAM/cooler/GPU/PSU/SSD fit; screw penetration, finish stacks and tool access; I/O variant/thread/plug fit; real cable routing and electrical operation; GPU support contact; protective-earth/bonding continuity; loaded thermal and handling tests.

The legacy Protocase/ATX PCI setback discrepancy is **0.4572mm**. Retention axes follow the selected source, not aperture centres. If the physical gauge fails, revise rear/rail/tray interfaces together before full cutting. Never treat a valid STEP or component box as proof that a real bracket fits.

Do not open, drill or modify the PSU or improvise mains wiring. Preserve its protective earth. Powder coat is insulating; modeled metal contact is not measured bonding or safety compliance.

## Editing and rebuilding

Native parts are individually editable, but this is **not a fully sketch-constrained parametric assembly**. `Source/Approved-design.FCStd` is an input baseline, not the current fabricated assembly. `Source/detail.py` completes the base and calls portable `finish_io.py`; historical local patches are unnecessary.

On a working copy, using Python able to import FreeCAD/Part:

```text
python3 Source/detail.py
python3 Source/export_flats.py
python3 Source/package_data.py
python3 Source/check_development.py
python3 Source/check_assembly.py
python3 Source/check_io.py
python3 Source/check_reference_intersections.py
python3 Source/export_models.py
```

For a subsystem-only update, `Source/finish_io.py` is idempotent and edits the delivered native model. `export_models.py` regenerates **uncoloured** STEP files and checks round trips; the distributed assembly STEP is coloured. PyMuPDF is needed for `Source/build_guide.py`; optional `M3_GUIDE_FONT` and `M3_GUIDE_PROOFS` configure font/proof paths.

After edits, update linked CAD, flats, drawings, schedules, checks and previews together. Read intersection reports; do not assume every overlap is harmless. Physical qualification remains separate from digital regeneration.
