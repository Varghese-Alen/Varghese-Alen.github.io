# Sheet Metal PC Case

A planning and engineering reference release of an unprototyped sheet-metal enclosure. **This is not a complete fabrication kit or a physically qualified product.**

## Start here

- [Drawings and Build Guide](Sheet%20Metal%20PC%20Case%20Drawings%20and%20Build%20Guide.pdf): 41 A3 pages of reference developments, dimensions, provisional bends, assembly, I/O and qualification guidance.
- [Assembly STEP](CAD/Sheet%20Metal%20PC%20Case%20Assembly.step): 290 solids, including nominal hardware and simplified component reference envelopes. Do not manufacture the component boxes.
- [Sheet Parts STEP](CAD/Sheet%20Metal%20PC%20Case%20Sheet%20Parts.step): 19 sheet instances in their **formed assembly positions**, including the three optional parts F01/G01/G02. This is not flat STEP.
- [Assembly notes](ASSEMBLY-NOTES.md) and [front I/O notes](IO-ASSEMBLY.md): controlling datums, joints, service access, selected connections and fit checks.
- `sheet-parts-bom.csv`, `hardware-bom.csv`, `purchased-components.csv`, `bend-schedule.csv` and `joint-schedule.csv`: planning quantities, nominal materials and stacks. Purchasing entries already counted in the hardware BOM are not additional quantities.
- `validation-summary.json` identifies the current STEP checks and the retained prior engineering records. `release-inventory.json` lists every supplied file.

**STEP is the only supplied design format. No flat cutting files, automatic unfolding, original feature tree or sketch constraints are included.** The PDF developments and bend coordinates are provisional references, not machine instructions or NC cutting authority. There are no hidden cutting downloads in the supporting data.

A fabricator must develop and qualify their own cutting patterns from the formed STEP geometry and controlling dimensions. Establish the actual material, grain direction, tooling, radii, bend allowances, springback, kerf and finish before producing a full case. Do not scale or trace PDF artwork as a substitute for this work. Alternative fascias and process coupons are reference configurations only, not separate supplied STEP parts. No STL is needed or supplied for this sheet-metal reference release.

## Design scope

Main shell: **302 × 410 × 520 mm**. Envelope including ordinary heads and the rear rail: **306.8 × 422 × 520 mm**. Each side has **546 round ventilation holes**. The provisional wrap development is **1238.0503 mm** long; brake and segmented-tool access require qualification.

The 19 sheet instances represent 18 designs, including three optional parts. Sides are 1.5 mm 5052-H32 aluminium; the wrap, tray, rear and other light steel details use 1 mm steel; the fascia is 1 mm aluminium; the nutstrip and optional GPU support use 3 mm steel. The sheet BOM gives each part's material and gauge.

Motherboard formats and component envelopes are design targets, not guaranteed combinations. Select only the actual board's standoff subset and gauge the real board, rear shield and card interfaces. The **0.4572 mm PCI setback discrepancy requires a physical bracket/card/cover gauge**. Handles are **unrated: empty-case handling only until load-qualified**.

## Front connections

Default: two USB-C, two USB-A, stereo audio and power. Each C uses a Newnex U4S5C01C08-010 and its own Delock 67234 with an independent supported Type-E host. The A pair uses Newnex USR2-AA-1M leads and one Delock 82941 19-pin adapter. FRONTX P0902_036 provides rear stereo-output pass-through, **not a microphone, HD_AUDIO connection or amplifier**. Power uses E-Switch PV0F24011 and an insulated PWR_SW pair.

Standard **5 V only**. No PD, Alt Mode, USB4, Thunderbolt or USB-IF certification claim. Test the complete electrical chain, current budget and C orientations. One supported Type-E host calls for the documented one-C configuration, not a splitter. Actual module threads, plug hoods, coating gaps, cable support and board-dependent tails require qualification; see the I/O notes.

## Evidence and next steps

Both STEP files have been freshly imported and checked for solid validity in this release; exact counts, volumes and bounds are in `export-validation.json`. Assembly volume includes reference envelopes and is **not enclosure material volume or mass**. Earlier assembly, clearance and routing records are retained with their original digital scope, not presented as newly performed tests. Nine intentional thread/tap-drill representations and eight SSD/PSU screw/reference-envelope intrusions remain explicit; real screw penetration must be checked.

No physical prototype, finished fit, coating, forming-tool access, electrical chain, bonding, loaded thermal or handling/load qualification is established. Preserve the PSU's protective earth; never open, drill or modify it or improvise mains wiring. Use the guide's physical qualification checklist before declaring any build ready. Engineering changes require coordinated updates to formed geometry, the fabricator's patterns, dimensions and checks.

## Licence

**CERN-OHL-P-2.0**. Read the full [licence](LICENSE.txt) and [notice](NOTICE.md). Supplier documents are linked for reference, not redistributed or relicensed. The release changes documentation and distribution scope, not the enclosure geometry.
