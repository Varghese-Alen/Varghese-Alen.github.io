# Sheet Metal PC Case

An unprototyped engineering design and build guide.

**This design has not been physically prototyped.** Qualify fabrication coupons, real interfaces and selected hardware before cutting a complete case. A completed digital model does not establish a tested product, handle rating, guaranteed component fit, USB certification or safety approval.

Licensed **CERN-OHL-P-2.0**. Full license: `LICENSE.txt`; third-party notice: `NOTICE.md`.

## Start here

**`Sheet Metal PC Case Drawings and Build Guide.pdf`: 41 A3 pages:** dimensions, individual developed blanks, bends, BOM, assembly/service, completed I/O mounting/wiring and physical qualification plan.

**`CAD/Sheet Metal PC Case.FCStd`:** authoritative editable assembly. Manufactured sheets, reference hardware and nonmaterial I/O routing constructions are distinguished in the tree.

**`CAD/Sheet Metal PC Case Flat Patterns.FCStd`:** editable individual blanks, not a cutting nest. Hide all except the selected PartID when inspecting overlapping local-coordinate blanks.

**`CAD/Sheet Metal PC Case Assembly.step`:** coloured solid assembly, including nominal hardware/component envelopes; nonmaterial routing wires are excluded.

**`CAD/Sheet Metal PC Case Sheet Parts.step`:** 19 manufactured sheet instances only, uncoloured. Do not manufacture the reference component boxes.

**`DXF/`:** millimetres, cut-only curves; bend lines are in the PDF/CSV, not laser-cut entities.

**`IO-ASSEMBLY.md` and `io-interfaces.json`:** exact selected I/O topology, mounting stack, assumptions, variants, source links and installation checks.

## Front I/O

The default fascia has **two C, two A, stereo audio and power**, with a shared concealed I03 mounting plate, real fixings and protected routing allocations. The mounting and routing design is documented below; actual fit and electrical operation still require physical qualification.

| Function | Selected parts / connection |
|---|---|
| Two C sockets | Two Newnex U4S5C01C08-010 panel cables; each male end connects through its own Delock 67234 to an independent Type-E/Key-A motherboard or controller port |
| Two A sockets | Two Newnex USR2-AA-1M panel cables connected to Delock 82941, using one conventional two-port 19-pin USB3 motherboard header |
| Stereo audio | FRONTX P0902_036, 36 in lead through the protected rear exit to a suitable rear stereo output; **not HD_AUDIO, headset microphone or an amplifier** |
| Power | Existing E-Switch PV0F24011 and insulated PWR_SW pair |

These substitute for the previously proposed Delock 85760/85244 and Adafruit 3319 interfaces because the selected panel modules have better public mechanical evidence. The design uses **commercial passive extension/header adapters**, not direct internal harnesses. Test enumeration, speed and current through the complete connected chain in all four local C orientation combinations (2 rear × 2 front). Repeat the tests if the device-end plug is reversible. No USB-IF certification, PD, Alt Mode, USB4 or Thunderbolt capability is claimed. Use standard 5 V host operation only; no passive Y splitter, legacy-A-to-C receptacle adapter or A-male/A-male cable.

If the motherboard has only one supported Type-E header, **use the one-C fascia**. Omit the lower C module, its adapter and its fixings rather than installing an unconnected second port. Alternative quantities are listed in `IO-ASSEMBLY.md`.

### What is sourced and what is allocated

Published flange dimensions, mounting pitches, C nose projection and rear-body/relief limits control the mounting design. Simplified component bodies are **not exact OEM CAD**. Check unpublished corner shapes, embedded-nut depth, A nose projection, cable bend limits and retail variant tolerances when the parts arrive and during trial fitting. The model does not supply manufacturer dimensions for these details.

The designer access openings are C 14 × 8 R2 and A 20 × 12 R1, slightly larger than the earlier artwork. Port centres and the 42 × 164 capsule are unchanged. C recess 1.3 mm is derived from its published 3.2 mm nose; the A recess of 4.5 mm is a reserve, not an OEM-exact setback. Use actual C plug hoods ≤12.2 × 6.4 and A≤18 × 10 as nominal access limits; qualify finish/corners and insertion. USB screw-head/fascia gap 0.35 mm and attachment-head/wrap gap 0.85 mm need finished-stack checks. Audio finished panel thickness must be **strictly below 1.2 mm**.

R50/Ø10 USB routing constructions are designer clearance allocations, not supplier minimum-bend or cable-OD specifications. Header tails depend on the selected motherboard. Secure all added mating pairs, support leads near headers and keep cables away from fans. The audio hood must pass the bare Ø12 rear hole before fitting the split grommet: maximum allowed hood Ø11; do not force a plug through the nominal Ø9 grommet bore.

## Approved case geometry retained

Main shell: **302 W × 410 D × 520 H mm**; upper width **290 mm**.

Including ordinary pan heads and rear rail: **306.8 W × 422 D × 520 H mm**. The earlier 2.2 mm overall-width increase was entirely the change from illustrative 1.3 mm to ordinary 2.4 mm screw heads; side planes did not move.

Sand sleds, forward handles, lower joggle, concentric capsule ventilation and charcoal single wrap remain.

No welding. Two ordinary M3 × 10 front bolts retain the carrier. The new I03 mounts to that carrier, with no additional shell holes or visible fascia screws.

Handles are **UNRATED: empty-case handling only until physically load-qualified**.

## Manufacturing files and quantities

The main sheet set contains **18 designs and 19 instances**, including opposite-handed sleds made from one blank design. F01 side-fan bridge and G01/G02 GPU support are optional. I03 is included in the full and one-C versions, omitted from power-only/blank versions.

There are **29 DXFs in total**: 18 main designs, 3 mutually exclusive fascia alternatives, 6 process coupons and 2 ancillary designs (ten 0.2 mm shims and one 0.5 mm gasket). Alternatives are substitutions, not extra installed sheets. Obsolete sample-gated port templates have been removed.

`panels.json`, `sheet-parts-bom.csv`: IDs, materials, gauges, quantities, blank sizes and unfinished material mass estimates.

`bend-schedule.csv`: exact flat-coordinate axes, signed path-turn angles, R/K/BA and forming order. Consult assembled PDF sections for UP/DOWN direction.

`flat-hole-schedule.csv`, `drawing-geometry.json`: complete hole/analytic geometry data.

`hardware-bom.csv`, `purchased-components.csv`, `joint-schedule.csv`: purchasing, nominal stacks and access. Purchasing entries already present in the hardware BOM are not additional quantities.

`ASSEMBLY-NOTES.md`: chassis assembly and critical motherboard/PCI datums.

`references.json` and `io-interfaces.json`: public sources and their limitations; supplier drawings are cited, not redistributed or relicensed.

K factors, radii and springback are provisional shop assumptions. Qualify material/joggle/insert coupons and segmented-brake access before cutting the 1238.0503 mm wrap. Use appropriate metalworking equipment and small-feature capability; deburr every handle, vent and cable passage. Do not scale PDF pictures or add kerf compensation to the master geometry.

## Digital checks

The native model and coloured STEP contain **287 solid-bearing leaves and 290 solids**. Both are valid, with an equal summed volume of **10,045,657.470 mm³** and identical bounds. Reference envelopes are included in this volume; it is not enclosure material volume or mass.

All **19 main sheet instances** are valid single solids, with no interference between sheets.

The **29 serialized DXFs contain 2,408 closed loops**, with no open or duplicate cuts. The maximum area mismatch is **1.518 × 10⁻⁶ mm²**.

The **2,333 circular cuts** were mapped through development to assembled holes and saved DXFs. The maximum coordinate error is **4.951 × 10⁻⁹ mm**.

The recorded portable source rebuild and repeated I/O update reproduced the counts, volume and bounds.

The I/O plate and hardware had no unexpected solid clashes. Ten continuous swept routing allocations were checked, with minimum nominal clearance of 3 mm for USB and approximately 2.994 mm for audio. This does not qualify unplaced board-specific tails or supplier bend limits.

Nine existing PCI major-thread/tap-drill overlaps and eight SSD/PSU screw/reference-envelope penetrations remain explicitly identified; actual allowed penetration is not waived. No STL validation is claimed.

See `export-validation.json`, `io-export-validation.json`, `model-export-check.json`, `io-clearance-check.json`, `development-check.json`, `folded-hole-alignment.json`, `dxf-validation.json`, `assembly-check.json`, `reference-intersections.json` and `io-source-validation.json`.

## Physical qualification still required

Physical qualification must cover process coupons and tool access; a gauge using the actual PCI card, cover and rear I/O; fit of the selected motherboard, RAM, cooler, GPU, PSU and SSD; screw penetration and finished stacks; I/O variants, threads and plugs; real cable routing and electrical operation; GPU support contact; protective-earth and bonding continuity; and loaded thermal and handling tests.

The Protocase/ATX PCI setback discrepancy is **0.4572 mm**. Retention axes follow the selected source, not aperture centres. If the physical gauge fails, revise rear/rail/tray interfaces together before full cutting. Never treat a valid STEP or component box as proof that a real bracket fits.

Do not open, drill or modify the PSU or improvise mains wiring. Preserve its protective earth. Powder coat is insulating; modeled metal contact is not measured bonding or safety compliance.

## Editing and rebuilding

Native parts are individually editable, but this is **not a fully sketch-constrained parametric assembly**. `Source/Approved-design.FCStd` is an input baseline, not the current assembly design. `Source/detail.py` completes the base and calls portable `finish_io.py`; historical local patches are unnecessary.

Run these commands on a working copy, using a Python environment that can import FreeCAD and Part:

```text
python3 Source/detail.py
python3 Source/export_flats.py
python3 Source/package_data.py
python3 Source/check_development.py
python3 Source/check_assembly.py
python3 Source/check_io.py
python3 Source/check_reference_intersections.py
python3 Source/export_models.py
```

For a subsystem-only update, `Source/finish_io.py` is idempotent and edits the delivered native model. `export_models.py` regenerates **uncoloured** STEP files and checks round trips; the distributed assembly STEP is coloured. PyMuPDF is needed for `Source/build_guide.py`; optional `PC_CASE_GUIDE_FONT` and `PC_CASE_GUIDE_PROOFS` configure font/proof paths.

After edits, update linked CAD, flats, drawings, schedules, checks and previews together. Read intersection reports; do not assume every overlap is harmless. Physical qualification remains separate from digital regeneration.
