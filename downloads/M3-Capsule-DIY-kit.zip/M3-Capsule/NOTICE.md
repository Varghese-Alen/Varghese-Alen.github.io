# Notice

SPDX-License-Identifier: CERN-OHL-P-2.0

The client selected CERN Open Hardware Licence Version2 — Permissive for this M3 Capsule design package. The full text is in LICENSE.txt (SPDX licence-list text mirror). Source location within this distribution: `Source/` and `CAD/`; including the editable native design is recommended for useful community sharing, not an additional condition beyond LICENSE.txt.

Third-party product names, specifications and cited documents remain their owners' material; this is not a trademark licence or an endorsement. Reference envelopes are our simplified layout geometry, not OEM replicas. No warranty, tested load rating or safety certification is provided. Preserve the qualification notices and identify your changes.
