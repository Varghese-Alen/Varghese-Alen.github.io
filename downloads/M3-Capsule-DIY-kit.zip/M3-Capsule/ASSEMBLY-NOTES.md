# M3 Capsule — unprototyped engineering kit

SPDX-License-Identifier: CERN-OHL-P-2.0

**Not a fabrication-ready certification, tested product, or load-rated enclosure.** Mandatory process coupons, a physical rear-interface gauge and selected-component fit checks precede a full case cut. This release candidate requires the physical qualification gates below before fabrication or use.

## 1. Controlling geometry and intentional changes

All dimensions are mm. Front is −Y, rear +Y, up +Z, motherboard component side +X. The approved native baseline is included in `Source/Approved-design.FCStd`; historical patch scripts are NOT rerun.

| Item | Final nominal geometry |
|---|---|
| Main sled footprint / height | 302 W ×410 D ×520 H; upper outside width290 |
| Overall including ordinary heads / PCI rail | **306.8 W ×422 D ×520 H**, bounds X−153.4…153.4, Y−205…217, Z0…520 |
| Difference from provisional overall width304.6 | +2.2 total: ordinary 2.4-high M3 pan heads replace illustrative1.3-high heads; side planes did not move |
| Sides | 1.5mm5052-H32; Ri2.25, K.40; opposed26.565051° bends, nominal outer virtual Z144/156 and6mm joggle |
| Single charcoal wrap | 1mmsteel; Ri1, K.42; opposed18.434949° front joggle plus floor/roof90° bends; front outerY−203/−199, floorZ25, roofZ458 |
| Wrap edge transition | Lower width298, upper286. Width tapers only on the straight inclined web between true bend tangencies. First joggle bend298wide, second286. No projected or open corner-relief approximation |
| Side fastenings | Per side: Y−165/0/165 atZ448; Y−165/+165 atZ11. Ten downward-folded wrap ears; upper ears below roof |
| Capsule grille | Original546 Ø3.5 bores per side retained;5mm staggered pitch,1.5mm nominal minimum web, approximately5mm solid bands |
| Visible front capsule | Unchanged42×164 opening. Hidden46×168 fascia,1mmaluminium, visible planeY−197.5 |
| Default front I/O | TwoC, twoA, stereo audio and power; completed I03 common concealed mounting plate and commercial header-adapter wiring. See IO-ASSEMBLY.md |
| SSD relocation | Body nowY60…129.85, Z200…300, X−124.5…−117.5: moved104.065 rearward from the approval envelope to clear standoffL and its new securing nut |
| Optional side fan | Frame moved3.5mm inboard toX115…140; mounted by removableF01 bridge, not floating |
| GPU support | Optional3mmsteel post/ledge, postX116.5…119.5; foot beginsX96; adjustableY/Z and padded ledge belowGPU |

The approved silhouette, handle cutouts, grille rings, component datums and single-wrap architecture are retained. The new ordinary roof/back/floor screws are real assembly details. The fully populated I/O is the default; one-C, power-only and blank faces are mutually exclusive alternatives.

## 2. Datums which must not drift

PCB Z125…429.8; A=(Y189.7318,Z141.51), **not146.51**. PCB rearY199.8918; rear innerY202; gap2.1082. PCB undersideX−106.975, topX−105.375; tray component faceX−116.5; standoff9.525. All12 corrected mounting positions are verified in `component-clearances.json`; install only those matching the actual board. Historical B, and microATX R/S, are not installed beneath the depicted ATX board.

Rear I/O X−109.2102…−64.7602, Z273.4884…432.2384:44.45×158.75, cornerR.8,1mmshield-interface gauge. Preserve ATX's2.54 clear band both faces and mask coating there. ATX source opening tolerance ±.2032 and datum-chain tolerances are not replaced by a blanket shop tolerance.

PCI slot pitch20.32 is retained. The nutstrip is X−1.7677…1.2323, Y203…217 and3mmthick; it never crosses the rear wall. Outer retention face remainsX2.2323. The seven retention axes follow the source: Z147.4841+n20.32, Y206.1148. They are NOT the aperture centres Z139.1656+n20.32. Two separate nutstrip attachment axes are Y214, Z130/272, clear of the retention washers. The adjacent rear clearance slit is X1…4.2, Z124…277, allowing ordinary Ø7 M3 washers without changing the seven aperture datums. The original bracket-relief profiles in M02 are retained. **A real bracket/cover/GPU interface gauge is mandatory.** Legacy Protocase/ATX setback chains differ0.4572mm, and neither advertising envelopes nor this nominal cage establish universal modernGPU bracket fit. If the gauge fails, revise the rear/rail/tray tip-pocket set together before full cutting.

## 3. Cut files, bend interpretation and shop sequence

`DXF/` contains18 main sheet designs, quantity19 pieces including two opposite-handed sleds. Ancillary cuts add10 nominal0.2 conductive head shims and one0.5 fascia gasket. Alternatives contain one-C, power-only and fully blank replacement fascias; use one face per case, with the corresponding I/O hardware quantities. Six process coupons remain. There are29 DXFs total. Obsolete sample-only USB templates have been removed.

Every DXF is cut-only in mm, closed, nonduplicate and without bend/construction entities. Do not scale a drawing or use a perspective projection as a blank. Laser kerf compensation belongs to the shop. `panels.json` gives raw flat local coordinates and the DXF-origin shift; `drawing-geometry.json` gives exact serialized line/arc/circle geometry, normalized to the lower-left blank bounding box. Subtract the stated origin from raw bend-axis coordinates when laying them over a DXF. `supplemental-blanks.json` controls ancillary/alternative/coupon quantities and materials.

The analytical model uses real tangent setbacks and neutral BA=abs(angleRadians)×(Ri+K×t). Constant-gauge CAD geometry is not an experimentally calibrated neutral-axis model: the small expected volume difference between the constant-gauge formed solid and K-developed blank is explicitly checked, not suppressed. `development-check.json` records that correction and residual. K, actual inside radii and springback are **provisional shop assumptions**.

1. Cut/process coupons in the actual material, rolling direction, tooling and finish. Verify R/K/springback and both joggle offsets. Use suitable segmented tooling/fingers for integral ears; confirm forming-tool access before cutting the1238.0503-long wrap blank.
2. Deburr every cut, particularly handles, grille webs, cable exits and PCI pockets. No sharp burrs inside a cable route. Preserve shield contact bands.
3. Sleds: same410×521.226384 cut blank, opposite fold hands; two opposed bends. Keep outside lower/upper planes at±151/±145. Do not form two identical hands.
4. Wrap: preform the ten side ears DOWN; form the two front-joggle bends next; floor90° then roof90° last, subject to actual brake/tool accessibility. `suggested_forming_step` distinguishes this order from path-order bend numbering.
5. Tray: two90° channel bends. Two local upper-flange edge reliefs clear the downward left wrap ears. All standoff holes remain simple clearance holes, not structural taps in1mmsteel.
6. Form C/T clips, carrier and optional fan bridge atRi1/K.42. Form3mmGPU support parts atRi3/K.40. M02's existing genuinely radiused1mm interface is retained; its two end-return segments can share a bend line with suitable tooling.
7. Tap all nine M03 holes M3×0.5 through3mm after cutting; deburr and gauge. Do not tap the1mmrail as the retaining structure.
8. Use two ordinary M3×10 pan screws through the front at X68/132, Z336 to secure the concealed carrier. Two small black external heads replace welding; no weld studs or structural adhesive are required.
9. Apply finish with masked grounding/contact regions. Recheck finished Ø5 insert pilots and the exact switch cutout. Protect small grille webs from handling damage.

## 4. Assembly and service

The complete fastener pairs, stacks, nominal engagement and access are in `joint-schedule.json`/CSV. `hardware-bom.csv` aggregates hardware; `hardware-bom-detail.json` retains instance intent. Native fasteners are simplified nominal envelopes with no thread helices, not OEM CAD.

### Chassis and sides

Install fourC clips between back and wrap with through-M3 screws/washers/nuts. Attach tray top/bottom flanges to wrap with fourM3 joints and connect its rear with twoT clips. These are genuine connected plates, not floating skins. Plain nuts remain accessible with the sides open; their service requirement is intentional.

Fit RRE03-1 inserts in the ten fixed1mmwrap ears, not through the removable sides. Supplier basis: finished pilotØ5, bodyØ4.9, reduced headØ6×.5,1mmgrip within0.5–2 range, unset length9 including head. The CAD depicts the published **unset envelope**; installed bulb shape, mandrel travel, setting force and nose envelope are unknown and must be qualified. Leave setter access open before chassis assembly.

Fixed flange outer planes are±142.8 upper and±148.8 lower, giving0.7 to the unchanged side inner planes. The.5 insert head plus nominal.2 shim fills that gap. Do not pull the side inward to hide a bad coated stack. Tune shim thickness to the measured finished stack while preserving side outer planes. M3×8 pan screws provide nominal4.8 useful engagement past the1mmgrip region. Test repeated removal, spin resistance and seating.

### Motherboard tray and SSD

Use9.525 female-M3/male-M3×5 standoffs, locknuts behind tray, and M3×6 board screws. The reference now has a connected solid base and6mmblind female bore; require at least4.4mmusable female engagement from the actual supplier. Only install the selected board's actual mounting subset. No unsupported1mmtapped tray holes. Install standoffs/SSD before board; verify no unused standoff can short a PCB.

SSD bottom screws are M3×4 through1mmtray, giving nominal3mm drive penetration; this is **not universal SSD permission**. Four centers Y64.065/125.785, Z286/209.4:61.72×76.6 rectangle, rows14/90.6 from connector-end body planeZ300. Body spans69.85 nominal acrossY and100 alongZ. The inferred4.065 edge offset and actual drive boss seating need a sample. Reserve the cable-side region aboveZ300 towardZ335 for SATA connectors;19mm nominal to left side. Route SATA leads without sharp folding or squeezing against the side; actual plug envelopes remain a gate.

For tray service: isolate power; remove side(s); unplug rear and internal leads; removeGPU and its support/clamp as necessary; release rearI/O shield/cables and the twoT connections; release four flange bolts. Move sufficiently forward to disengage the rear interface, then extract through the open side. This sequence is a manual access plan, not a verified automated assembly-sweep simulation. Do not force a fully connected board assembly sideways.

### PSU and fans

Four Ø8×8 blind-M3 support bosses atX−45/+85,Y95/190, topZ34, bolt from below withM3×6. Their contact is digitally verified for all140/160/180 depths. A nominal6deep blind bore leaves2mmtop wall; screw engages5 after the1mmfloor. No PSU modification.

Rear #6-32 pattern is handed from the Intel external AC-face view: globalX=95−drawingX, Z=34+drawingY. Global pairs are (−49,114),(89,114),(89,50),(−25,40). The depicted #6-32×1/4 screws give5.35 nominal penetration through the back; check the actual PSU allowed length. Do not flip the PSU and assume this asymmetric pattern still applies. Retain180depth plus60front cable reserve.

Bottom140 uses fourM4×35 through bolts. Rear140 uses **M4×30**, plain nuts and .8 washers:1back+25fan+.8washer+3.2nut=30, nominal flush full-nut engagement. Check actual stack and use appropriate removable thread locking; do not substitute thick nylocs. M4×35 rear screws clash with the optional side bridge. Alternate120 patterns remain in the floor/rear sheets but are not extra installed fans.

Optional120: install fourM4×35 intoF01 on the bench, then attach the whole bracket to the roof with twoM3 joints. Fan pitch105, frameX115…140; bracketX114…115. Ordinary3mmheads endX143,0.5 from side inner face143.5 before finish. Cooler tip to frame42.375, to bracket41.375; fan-frame rear gap7. Remove roof connections to service the complete module rather than trying to hold hidden nuts through a spinning fan. Isolate power first.

### PCI and GPU support

Fit M03 behind M02 with two endM3×5 screws. Use ordinary M3 washers over bracket notches and M3×6 retention screws into3mmstrip. The seven purchased standard full-height PCI covers are listed in the BOM, not modeled as fake rectangles; substitute the real card bracket for occupied positions. The model's washers reserve a nominal1mm bracket/cover layer, so that layer is intentionally absent in CAD. Buy/gauge the actual covers and card together with the rear cage.

G01 bolts through a continuous54long floor slot with twoM4×10 joints. It beginsX96,6 clear of the bottomfan'sX90 limit. G02 clamps through two vertical slots withM4×12. Its topZ193 plus2mmnonconductive pad meets nominalGPU undersideZ195. SetY and height to an actual stiff, nonfan card surface; do not press on a fan, PCB component or unsupported plastic shroud. The ledge remains below the35mm connector reserve. This is an optional untested support, not a lifting/shipping restraint or rated cantilever. If the selected card cannot be supported there, use its maker's support and recheck envelopes.

## 5. Completed front I/O

Follow **IO-ASSEMBLY.md** and the guide's completed I/O sections for mounting, connection topology, cable restraint and variants. The default face has2C/2A/stereo audio/power at the original centres. I03 is a common1mmsteel mounting plate behind I02, with four carrier fixings and eight module fixings; its R4.5 edge scallops clear existing carrier joints. No added shell holes, welding or visible fascia screws.

Selected C: Newnex U4S5C01C08-010 through one Delock67234 per supported Type-E host. Selected A: Newnex USR2-AA-1M through Delock82941 to one19-pin two-port host header. Audio: FRONTX P0902_036 stereo rear-output pass-through, not HD_AUDIO/headset/amp. Power PV0F24011 is unchanged:Ø12.1 aperture,14bezel,9actuator,M12×.75,18±1 under-bezel terminal depth; supplied nut/O-ring and insulated PWR_SW leads. Install power/audio on the removed face before closing the carrier, maintaining nut/tool access.

This is a commercial passive extension/header-adapter architecture, not a direct harness or USB-IF-certified chain. Standard5V host only; no PD/AltMode/USB4/Thunderbolt claim. Two C require two independent supported Type-E connections. Use the one-C face if only one is available; no Y or legacy-A-to-C-socket adapter, and never an A-male/A-male cable. Qualify the whole connected chain, both C orientations, current and hotplug.

Designer access openings: C14×8R2, A20×12R1. C nose recess1.3 is derived from its published3.2 projection. A4.5 is a reserve recess because forward projection is unpublished, not an OEM-exact datum. Actual C hoods≤12.2×6.4 and A≤18×10 are nominal access limits; qualify finished corners and shoulders. Simplified modules are declared allocations, not exact supplier models.

Use specified ISO7380 button heads, not taller pan heads. Nominal head gaps0.35 to fascia and0.85 to wrap need coating/flatness checks. Eight M3×4 module screws give2.5 nominal engagement after1mmplate+.5washers; embedded-nut depth is unpublished, so check bottoming and clamp. Maintain flangefrontY−193 if factory screws/spacers are substituted.

Audio uses supplierØ6.1 cutout and supplied nut; finished panel must be strictly<1.2. Pass a hood≤11 through bare deburred rearØ12 before fitting the split nominalID9 grommet around the cable. Do not assume a plug fits throughID9. Routing constructions allocate R50/Ø10 USB bends and service loops, cushioned restraint and a protected audio lane; they are not supplier minimum-bend/OD specifications. Actual board-dependent tails must be supported clear of fans and must not lever the headers. All actual-fit/electrical prototype tests remain mandatory, not requests for missing design inputs.

## 6. Bonding, handling and prototype gates

Provide the dedicatedM4 chassis bonding point atX130,Z250 on the back. Use an appropriate ring lug/toothed contact stack on a masked metal area; final lug thickness and screw engagement need the actual part. Keep protective-earth arrangements of the certifiedPSU intact. Never open, drill or modify the PSU or improvise mains wiring.

Mask conductive contact annuli at selected side fasteners/shims, rear-to-wrap clips and tray joints; protect exposed contacts against compatible corrosion. A possible conductive path through hardware is **not measured protective-earth continuity**. Powder coating is insulating. Test chassis, both removable sleds, tray and carrier continuity with the actual finish; add short serviceable bonding braids to appropriate masked stud/lug points if required by the applicable electrical-safety review. Do not rely on anodized/painted contact or assume an insert automatically bonds. Keep braids clear of fans and leave disconnect access. No EMI/ESD or mains safety compliance claim is made.

Handles remain **UNRATED**. Deburr and use only for empty-case handling until a controlled proof/load programme establishes a limit; do not carry a populated case or use it as a shipping handle. No structural FEA, physical prototype, thermal/airflow, vibration, fatigue, acoustic, EMI, electrical-safety or coating durability validation was performed.

Mandatory gates before a full build: bend/joggle/tool-access coupons; insert setting/head stack/removal; bolted carrier stack; rearI/O and real PCI/card gauge; actualPSU screw intrusion and support seating; motherboard/cooler/RAM; SSD screw/cable fit; selectedfan fastener thickness and head clearance; GPU support contact/stiffness; actualI/O modules/adjacent plugs/header count/cable reach; grommet/strain relief; bonding continuity and loaded thermal tests. Changes from those gates require updating native, flats and schedules together.

## 7. Digital check results and limits

- Native and coloured STEP: **287 solid-bearing leaf objects,290 solids**, valid; same summed volume **10,045,657.470mm³** and identical bounds/size above. The three fan references each contain frame/rotor sub-solids; those3extra solids are intentional retail-envelope compounds. No STL was requested or claimed checked.
- All19 main manufactured sheet instances are valid single solids. Eighteen unique main flat designs pass exact analytic constant-gauge/neutral-development checks; maximum residual7.794665179972071e−8mm³ after the stated K correction.
- All2333 circular cuts across the18 unique designs map back to actual assembled cylinder axes and serialized DXF coordinates; maximum coordinate mismatch4.95055019201e-09mm. The opposite sled adds the mirrored551 circular cuts. Handles/outer profiles originate from the approved native solid, not screenshots.
- **29 serialized DXFs;2408 closed loops; zero open nodes or duplicate cut entities.** Maximum readback area error1.5179975889623165e−6mm². These are actual saved-file readbacks.
- No positive-volume manufactured/main-manufactured interference. Nine expected screw-major-diameter vs M03 tap-drill overlaps are retained in `assembly-check.json` as explicit thread representations, not silently waived geometry errors. Eight reference-envelope overlaps are the four SSD and fourPSU screw intrusions into undrilled component boxes; allowed penetration remains a physical gate. The earlier tray/ear andSSD/standoff clashes were corrected and rechecked.
- All12 corrected board positions, allthreePSU depths and the modeled35GPU/60PSU reserves pass their digital checks. Real connector, motherboard detail, bracket, tool and cable shapes are not established by boxes.

The new I/O hardware has zero unexpected clashes. Ten continuous routing allocations were checked against solids; USB clearance minimum3mm and audio about2.994mm. Unplaced header tails and unknown supplier bend limits are not certified. Portable source and idempotent subsystem regeneration passed. See the machine-readable validation files for exact results. A valid export is not physical fit or manufacturing certification.
